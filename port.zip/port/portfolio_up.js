// alert("Welcome to my Portfolio")

function button(){

  var main = document.getElementById("home").style.backgroundImage ;
  var first =  'url("web/main.gif")';
  var sec = 'url("web/main2.gif")';
  if (document.getElementById("home").style.backgroundImage==first){
    document.getElementById("tit").innerHTML= "Get to Know Me"
    document.getElementById("home").style.backgroundImage = sec;

  }else{
    document.getElementById("tit").innerHTML= "Sana Imtiaz"
    document.getElementById("home").style.backgroundImage= first;

  }
}

function bg2(){
  document.getElementById("pro").style.backgroundColor= "ivory";
  document.getElementById("pro1").style.backgroundColor= "ivory";
  document.getElementById("pro2").style.backgroundColor= "ivory";
  document.getElementById("pro3").style.backgroundColor= "ivory";



}
